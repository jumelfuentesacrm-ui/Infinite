-- =========================================================
-- INFINITE — base de datos de solicitudes
-- Pega TODO esto en Supabase > SQL Editor > Run
-- =========================================================

create table if not exists public.leads (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  nombre     text not null,
  negocio    text,
  email      text not null,
  telefono   text,
  servicio   text,
  mensaje    text,
  estado     text not null default 'nuevo',
  notas      text default ''
);

-- índice para ordenar rápido por fecha
create index if not exists leads_created_idx on public.leads (created_at desc);

-- seguridad a nivel de fila
alter table public.leads enable row level security;

-- 1) cualquiera puede ENVIAR el formulario (insertar)
drop policy if exists "web puede insertar" on public.leads;
create policy "web puede insertar"
  on public.leads for insert
  to anon, authenticated
  with check (true);

-- 2) SOLO usuarios con sesión pueden ver / editar / borrar
drop policy if exists "admin puede leer" on public.leads;
create policy "admin puede leer"
  on public.leads for select
  to authenticated
  using (true);

drop policy if exists "admin puede editar" on public.leads;
create policy "admin puede editar"
  on public.leads for update
  to authenticated
  using (true) with check (true);

drop policy if exists "admin puede borrar" on public.leads;
create policy "admin puede borrar"
  on public.leads for delete
  to authenticated
  using (true);

-- =========================================================
-- Después de correr esto:
-- Authentication > Users > Add user
-- Crea tu usuario admin con email y contraseña.
-- Ese es el que usarás para entrar a /admin.html
-- =========================================================
